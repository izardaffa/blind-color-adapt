const brightness = document.getElementById('brightness');
const contrast = document.getElementById('contrast');
const saturate = document.getElementById('saturate');
const hue = document.getElementById('hue');
const toggle = document.getElementById('toggleFilter');
const resetBtn = document.getElementById('reset');
const buttons = document.querySelectorAll('[data-mode]');

function updateFilter(enabled = true) {
  const values = {
    brightness: brightness.value,
    contrast: contrast.value,
    saturate: saturate.value,
    hue: hue.value,
    enabled: enabled
  };

  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const tabId = tabs[0].id;

    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['content.js']
    }, () => {

      chrome.tabs.sendMessage(tabId, { action: 'applyFilter', values });
    });
  });
}


[brightness, contrast, saturate, hue].forEach(input => {
  input.addEventListener('input', () => updateFilter(true));
});


toggle.addEventListener('change', () => {
  updateFilter(toggle.checked);
});


resetBtn.addEventListener('click', () => {
  brightness.value = 100;
  contrast.value = 100;
  saturate.value = 100;
  hue.value = 0;
  toggle.checked = false;
  updateFilter(false);
});


buttons.forEach(btn => {
  btn.addEventListener('click', () => {
    const mode = btn.dataset.mode;
    let values = {
      brightness: 100,
      contrast: 100,
      saturate: 100,
      hue: 0
    };

    if (mode === 'protanopia') values = { saturate: 30, hue: 0, brightness: 110, contrast: 120 };
    if (mode === 'deuteranopia') values = { saturate: 40, hue: 20, brightness: 110, contrast: 110 };
    if (mode === 'tritanopia') values = { saturate: 50, hue: 60, brightness: 100, contrast: 100 };
    if (mode === 'achromatopsia') values = { saturate: 0, hue: 0, brightness: 100, contrast: 100 };
    if (mode === 'normal') values = { saturate: 100, hue: 0, brightness: 100, contrast: 100 };


    brightness.value = values.brightness;
    contrast.value = values.contrast;
    saturate.value = values.saturate;
    hue.value = values.hue;

    toggle.checked = true;
    updateFilter(true);
  });
});
