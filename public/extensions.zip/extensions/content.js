chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'applyFilter') {
    const values = request.values;
    if (values.enabled) {
      document.documentElement.style.filter = `brightness(${values.brightness}%) contrast(${values.contrast}%) saturate(${values.saturate}%) hue-rotate(${values.hue}deg)`;
    } else {
      document.documentElement.style.filter = '';
    }
  }
});